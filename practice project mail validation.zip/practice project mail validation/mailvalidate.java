package mailvalidation;
import java.util.Scanner;
public class validate {
	public static void main(String[] args) {
		String mail[]= {"suriya@gmail.com",
				"sangavi@gmail.com","praveen@gmail.com","krishna@gmail.com"};
		boolean ch= false;
		Scanner scan=new Scanner(System.in);
		System.out.print("enter the mail id:");
		String name=scan.nextLine();
		//System.out.println(name.length());
		
		for (int i = 0; i < mail.length; i++) {  
            if(name.equals(mail[i])) {  
                 ch = true; 
                 break;  
            }
        }  
        if(ch) {  
            System.out.println("Email is found");
        }
        else {
            System.out.println("Email is not found");
        }
	}
}
