package filehandling;

import java.io.IOException;
import java.util.Scanner;

public class MainFile {
	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		FileRead fr=new FileRead();
		FileAppend fa=new FileAppend();
		FileWrite fw=new FileWrite();
		System.out.println("Enter 1:To write file");
		System.out.println("Enter 2:To read file ");
		System.out.println("enter 3:To append file ");
		System.out.println("enter the operation needs to perform");
		int choice=sc.nextInt();
		switch (choice) {
		case 1:
			fw.writes();
			break;
		case 2:
			fr.reads();
			break;
		case 3:
			fa.appends();
			break;
		default:
			System.out.println("Enter valid operation");
			break;
		}
		sc.close();
	}
}
