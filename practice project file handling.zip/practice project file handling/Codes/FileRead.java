package filehandling;

import java.io.FileInputStream;
import java.io.IOException;

public class FileRead {
	void reads() throws IOException {
		FileInputStream fn=new FileInputStream("input");
		if(fn!=null){
			System.out.println("file is present");
		}
		int i=0;
		while((i=fn.read())!=-1) {
			System.out.print((char)i);
		}
		fn.close();
	}
	
}
