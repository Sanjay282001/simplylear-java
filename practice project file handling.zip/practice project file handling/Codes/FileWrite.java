package filehandling;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class FileWrite {
	 void writes() throws IOException {
		FileOutputStream fn=new FileOutputStream("input");
		System.out.println();
		if(fn!=null) {
			System.out.println("file created and ready to write");
		}
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the name that have to enter in the file:");
		String write=sc.nextLine();
		byte b[]=write.getBytes();
		fn.write(b);
		System.out.println("write completed");
		fn.close();
		sc.close();
	}

}
