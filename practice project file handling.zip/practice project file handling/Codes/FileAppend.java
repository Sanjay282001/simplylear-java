package filehandling;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileAppend {
	void appends() throws IOException {
		FileWriter fn=new FileWriter("input",true);
        if(fn!=null) {
        	System.out.println("file is present");
        }
        Scanner sc=new Scanner(System.in);
        System.out.println("write the detail to apppend in file");
        String appe=sc.nextLine();
        fn.write(" "+appe);
        System.out.println("details have bean append");
        fn.close();
        sc.close();
	}	
}
